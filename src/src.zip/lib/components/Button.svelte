<script lang="ts">
    export let href: string;
    export let color: string;
</script>

<a href="{href}" class="{color} button">
    <slot />
</a>

<style lang="stylus">
    @font-face
        font-family 'Poppins'
        src url('./lib/fonts/Poppins/Poppins-Black.ttf') 

    a
        padding 10px
        border-radius 10px
        text-decoration none
        font-family "Poppins", sans-serif
        font-size 23px
        width 100%
        text-align center
        border 2px white solid
        transition ease .3s
        font-weight 500

    .grey
        color white
        background #495464

        &:hover
            color white
            background #57D131
            border #57D131 2px solid

    .ghost
        color black
        background white
        border black 2px solid

        &:hover
            color white
            background #57D131
            border #57D131 2px solid

</style>
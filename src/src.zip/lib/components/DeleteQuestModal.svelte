<script lang="ts">
    // Přijímání props přes $props() a reaktivní proměnné přes $state()
    let { questTitle, onConfirm, onCancel } = $props();
    let deleteQuestText = $state(''); // Reaktivní stav pro text
    let errorMessage = $state(''); // Reaktivní stav pro chybovou zprávu

    function confirmDelete() {
        if (deleteQuestText === `DELETE ${questTitle}`) {
            onConfirm(); // Potvrzení smazání questu
        } else {
            errorMessage = 'Nesprávně zadaný text! Zadejte "DELETE {název questu}".';
        }
    }
</script>

<div class="modal">
    <div class="modal-content">
        <h3>Delete Quest</h3>
        <p>Pro odstranění zadejte: <strong>DELETE {questTitle}</strong></p>
        <input bind:value={deleteQuestText} type="text" placeholder="DELETE {questTitle}" />
        {#if errorMessage}
            <p class="error">{errorMessage}</p>
        {/if}
        <button onclick={confirmDelete}>Delete</button>
        <button onclick={onCancel}>Cancel</button>
    </div>
</div>

<style lang="stylus">
    .modal
        position fixed
        top 0
        left 0
        width 100%
        height 100%
        display flex
        justify-content center
        align-items center
        background rgba(0, 0, 0, 0.5)

    .modal-content
        background white
        padding 20px
        border-radius 10px
        display flex
        flex-direction column
        gap 10px

    .error
        color red
</style>

export function load({ url }) {
    return {
      url: url.pathname,
    }
  }
  
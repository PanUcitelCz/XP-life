<script lang="ts">
	import { page } from '$app/stores';
</script>

<h1>{$page.error?.message}</h1>
<p>Nejste přihlášený</p>

<a href="/login">Login</a>
<a href="/register">Register</a>
<a href="/">Home page</a>

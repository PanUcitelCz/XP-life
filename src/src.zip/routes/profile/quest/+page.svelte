<script lang="ts">
    // Import potřebných komponent
    import QuestCard from '$lib/components/QuestCard.svelte';
    import ModalQuest from '$lib/components/ModalQuest.svelte';
    import AddQuestModal from '$lib/components/AddQuestModal.svelte';

    // Typ pro quest
    type Quest = {
      id: number;
      title: string;
      category: string;
      createdAt: string;
      description: string;
      isCompleted: number; // přidán stav dokončení
    };

    // Reaktivní stavy pro questy a zobrazení modálů
    let reactiveQuests: Quest[] = $state([]);
    let showCompleteQuestModal = $state(false);
    let showAddQuestModal = $state(false);
    let selectedQuest: Quest | null = $state(null);

    // Funkce pro načtení questů z API
    async function loadQuests() {
      try {
        const response = await fetch('/api/get-quest', {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json'
          }
        });

        if (response.ok) {
          reactiveQuests = await response.json();
        } else {
          console.error('Failed to load quests');
        }
      } catch (error) {
        console.error('Error loading quests:', error);
      }
    }

    // Volání funkce pro načtení questů při načtení komponenty
    loadQuests();

    // Funkce pro potvrzení dokončení questu
    async function completeQuest() {
      if (selectedQuest) {
        const response = await fetch('/api/complete-quest', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ questId: selectedQuest.id })
        });

        if (response.ok) {
          reactiveQuests = reactiveQuests.map((quest) =>
            quest.id === selectedQuest?.id ? { ...quest, isCompleted: 1 } : quest
          );
          closeModal();
        } else {
          console.error('Failed to complete quest');
        }
      }
    }

    // Funkce pro přidání nové aktivity
    async function addQuest(title: string, description: string, category: string) {
      const response = await fetch('/api/add-quest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, description, category })
      });

      if (response.ok) {
        const newQuest = await response.json();
        // Po úspěšném přidání znovu načteme všechny questy
        await loadQuests();
        closeAddQuestModal();
      } else {
        console.error('Failed to add quest');
      }
    }

    // Otevření modálů
    function openCompleteQuestModal(quest: Quest) {
      selectedQuest = quest;
      showCompleteQuestModal = true;
    }

    function openAddQuestModal() {
      showAddQuestModal = true;
    }

    // Zavření modálů
    function closeModal() {
      showCompleteQuestModal = false;
      selectedQuest = null;
    }

    function closeAddQuestModal() {
      showAddQuestModal = false;
    }
</script>

    <!-- HTML část pro aktivní questy -->
    <h2>Active Quests</h2>
    <p>Complete your quests to earn points!</p>

    <!-- Tlačítko pro přidání nové aktivity -->
    <button onclick={openAddQuestModal}>Add Quest</button>

  <div class="quest-grid">
    {#each reactiveQuests.filter((quest) => quest.isCompleted === 0) as quest (quest.id)}
      <div>
        <QuestCard activity={quest} onAddXP={() => openCompleteQuestModal(quest)} />
      </div>
    {/each}
  </div>

  <!-- HTML část pro dokončené questy -->
  <h2>Completed Quests</h2>
  <p>These quests have already been completed.</p>

  <div class="quest-grid">
    {#each reactiveQuests.filter((quest) => quest.isCompleted === 1) as quest (quest.id)}
      <div>
        <QuestCard activity={quest} onAddXP={() => {}} />
      </div>
    {/each}
  </div>

  <!-- Modály -->
  <ModalQuest questTitle={selectedQuest?.title ?? ''} showModal={showCompleteQuestModal} onConfirm={completeQuest} />
  {#if showAddQuestModal}
    <AddQuestModal onConfirm={addQuest} onCancel={closeAddQuestModal} />
  {/if}

  <style lang="stylus">
    .quest-grid
      display grid
      grid-template-columns repeat(auto-fill, minmax(250px, 1fr))
      gap 20px

    button
      margin-top 20px
      padding 10px
      background-color #007bff
      color white
      border none
      cursor pointer

    button:hover
      background-color #0056b3
  </style>

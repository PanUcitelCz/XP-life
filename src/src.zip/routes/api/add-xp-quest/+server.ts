import { questsTable } from '$lib/db/schema';
import { db } from '$lib/db'; // Připojení k databázi
import { eq } from 'drizzle-orm';

export const POST = async ({ request }: { request: Request }) => {
  try {
    const { questId } = await request.json();

    // Změní isCompleted na 1
    const result = await db
      .update(questsTable)
      .set({ isCompleted: 1 }) // Aktualizace sloupce isCompleted na 1
      .where(eq(questsTable.id, questId))
      .run();

    if (result) {
      return new Response(JSON.stringify({ success: true }), { status: 200 });
    } else {
      return new Response(JSON.stringify({ error: 'Failed to complete quest' }), { status: 500 });
    }
  } catch (error) {
    console.error('Failed to complete quest:', error);
    return new Response(JSON.stringify({ error: 'Internal server error' }), { status: 500 });
  }
};

import { db } from '$lib/db';
import { eq } from 'drizzle-orm';
import { questsTable } from '$lib/db/schema';
import { json } from '@sveltejs/kit';

export const DELETE = async ({ request, locals }) => {
  const { questId } = await request.json();

  // Ověření, zda je uživatel přihlášen
  if (!locals.user) {
    return json({ error: 'Not authenticated' }, { status: 401 });
  }

  try {
    // Použití Drizzle ORM k smazání questu na základě ID a uživatele
    await db.delete(questsTable).where(eq(questsTable.id, questId)).run();

    return json({ success: true });
  } catch (error) {
    console.error('Error deleting quest:', error);
    return json({ error: 'Failed to delete quest' }, { status: 500 });
  }
};
